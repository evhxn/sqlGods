//
//  GroceryAppTutApp.swift
//  GroceryAppTut
//
//  Created by Ahmed Gagan on 15/01/23.
//

import SwiftUI

@main
struct GroceryAppTutApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
