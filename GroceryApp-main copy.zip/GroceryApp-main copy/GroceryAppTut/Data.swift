//
//  Data.swift
//  GroceryAppTut
//
//  Created by Ahmed Gagan on 15/01/23.
//

import SwiftUI

var shopItems: [[Any]] = [
    ["avocado", "Avocado", 4.00, Color.green],
    ["banana", "Banana", 2.50, Color.yellow],
    ["chicken", "Chicken", 12.80, Color.red],
    ["water", "Water", 1.00, Color.blue],
]

var cartItems: [[Any]] = [

]
